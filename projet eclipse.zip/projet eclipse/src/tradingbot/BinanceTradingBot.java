package scrapv1;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.LinkedList;
import java.util.Scanner;

public class BinanceTradingBot {
    public static void main(String[] args) {
        // Scanner pour demander le nombre d'itérations à l'utilisateur
        Scanner scanner = new Scanner(System.in);
        System.out.print("Entrez le nombre d'itérations : ");
        int iterations = scanner.nextInt();

        // URL de la page à scraper
        String url = "https://www.binance.com/fr/trade/USDC_USDT";
        // Fichier CSV de sortie
        String csvFilePath = "BinanceTradingData.csv";

        // Format de la date et de l'heure
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

        // Liste pour stocker les 15 dernières valeurs
        LinkedList<Double> last15Values = new LinkedList<>();
        boolean hasActiveBuy = false; // Indicateur pour savoir si un achat a été effectué
        double buyPrice = 0; // Stocker le prix d'achat

        try (FileWriter writer = new FileWriter(csvFilePath, true)) {
            // Écriture de l'en-tête dans le fichier CSV
            writer.append("Timestamp,Value,AverageComparison,Action\n");

            // Boucle pour le nombre d'itérations spécifié
            for (int i = 0; i < iterations; i++) {
                long startTime = System.currentTimeMillis(); // Début de l'itération

                try {
                    // Connexion à la page et récupération du document HTML
                    Document doc = Jsoup.connect(url).get();

                    // Récupération du titre de la page
                    String title = doc.title();

                    // Extraction de la valeur avant le premier espace
                    String firstValue = title.split(" ")[0];
                    double currentValue = Double.parseDouble(firstValue);

                    // Ajouter la valeur actuelle à la liste
                    last15Values.add(currentValue);

                    // Si plus de 15 valeurs, supprimer la plus ancienne
                    if (last15Values.size() > 15) {
                        last15Values.removeFirst();
                    }

                    // Calcul de la moyenne des 15 dernières valeurs
                    double sum = 0;
                    for (double value : last15Values) {
                        sum += value;
                    }
                    double average = sum / last15Values.size();

                    // Action par défaut
                    String action = "null";

                    // Logique d'achat et de vente
                    if (!hasActiveBuy && average > currentValue) {
                        // Déclencher un achat
                        action = "achat";
                        hasActiveBuy = true;
                        buyPrice = currentValue;
                    } else if (hasActiveBuy && currentValue > buyPrice) {
                        // Déclencher une vente
                        action = "vente";
                        hasActiveBuy = false;
                        buyPrice = 0; // Réinitialiser le prix d'achat
                    }

                    // Récupération de la date et de l'heure actuelles
                    String timestamp = LocalDateTime.now().format(formatter);

                    // Affichage dans les logs
                    System.out.println(timestamp + "," + currentValue + "," + average + "," + action);

                    // Écriture dans le fichier CSV
                    writer.append(timestamp)
                          .append(",").append(String.valueOf(currentValue))
                          .append(",").append(String.valueOf(average))
                          .append(",").append(action)
                          .append("\n");
                    writer.flush(); // S'assurer que les données sont écrites immédiatement dans le fichier
                } catch (Exception e) {
                    // En cas d'erreur, afficher l'exception et continuer
                    e.printStackTrace();
                }

                // Calcul du temps restant pour compléter une seconde
                long elapsedTime = System.currentTimeMillis() - startTime;
                long sleepTime = 1000 - elapsedTime;

                // Attendre seulement si le temps écoulé est inférieur à 1 seconde
                if (sleepTime > 0) {
                    try {
                        Thread.sleep(sleepTime);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }

            System.out.println("Collecte terminée. Données enregistrées dans le fichier : " + csvFilePath);
        } catch (IOException e) {
            e.printStackTrace();
        }

        scanner.close();
    }
}

