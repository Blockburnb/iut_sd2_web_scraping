/**
 * 
 */
/**
 * 
 */
module scrapv1 {
	requires org.jsoup;
}